import { useEffect, useMemo, useRef, useState } from 'react'
import { EditorContent, useEditor } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Underline from '@tiptap/extension-underline'
import {
  AlignLeft, Bold, Check, ChevronDown, Clock3, Cloud, FilePlus2, FileText, FolderOpen,
  Heading1, Heading2, Italic, List, ListOrdered, MoreHorizontal, Search, Share2,
  Sparkles, Underline as UnderlineIcon, Upload, Users, X, Download, Menu, Trash2
} from 'lucide-react'
import { canAccess, createDocument, getActiveUser, importTextFile, loadDocuments, saveDocuments, setActiveUser } from './lib/storage'
import { hasCloudStorage, supabase } from './lib/supabase'
import { DEMO_USERS, type DocumentRecord } from './types'

type Filter = 'all' | 'owned' | 'shared'
type Toast = { message: string; kind?: 'success' | 'error' } | null

function relativeTime(value: string) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 1000))
  if (seconds < 60) return 'just now'
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
  return `${Math.floor(seconds / 86400)}d ago`
}

function ToolbarButton({ label, active, onClick, children }: { label: string; active?: boolean; onClick: () => void; children: React.ReactNode }) {
  return <button type="button" title={label} aria-label={label} className={`tool-button ${active ? 'active' : ''}`} onClick={onClick}>{children}</button>
}

export default function App() {
  const [documents, setDocuments] = useState<DocumentRecord[]>(() => loadDocuments())
  const [activeEmail, setActiveEmail] = useState(() => getActiveUser())
  const [activeId, setActiveId] = useState('welcome-doc')
  const [filter, setFilter] = useState<Filter>('all')
  const [search, setSearch] = useState('')
  const [toast, setToast] = useState<Toast>(null)
  const [shareOpen, setShareOpen] = useState(false)
  const [shareEmail, setShareEmail] = useState('')
  const [shareError, setShareError] = useState('')
  const [mobileNav, setMobileNav] = useState(false)
  const [moreOpen, setMoreOpen] = useState(false)
  const fileInput = useRef<HTMLInputElement>(null)
  const currentUser = DEMO_USERS.find(user => user.email === activeEmail) ?? DEMO_USERS[0]

  const visibleDocs = useMemo(() => documents.filter(doc => canAccess(doc, activeEmail))
    .filter(doc => filter === 'owned' ? doc.owner === activeEmail : filter === 'shared' ? doc.owner !== activeEmail : true)
    .filter(doc => doc.title.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)), [documents, activeEmail, filter, search])

  const activeDoc = documents.find(doc => doc.id === activeId && canAccess(doc, activeEmail)) ?? visibleDocs[0] ?? null

  useEffect(() => {
    if (activeDoc && activeDoc.id !== activeId) setActiveId(activeDoc.id)
  }, [activeDoc?.id])

  useEffect(() => { saveDocuments(documents) }, [documents])
  useEffect(() => {
    if (!toast) return
    const timeout = window.setTimeout(() => setToast(null), 3000)
    return () => window.clearTimeout(timeout)
  }, [toast])

  const editor = useEditor({
    extensions: [StarterKit, Underline],
    content: activeDoc?.content ?? '<p></p>',
    editable: Boolean(activeDoc),
    editorProps: {
      attributes: { class: 'tiptap-editor', 'aria-label': 'Document content editor', spellcheck: 'true' }
    },
    onUpdate: ({ editor: instance }) => {
      const content = instance.getHTML()
      setDocuments(old => old.map(doc => doc.id === activeId ? { ...doc, content, updatedAt: new Date().toISOString() } : doc))
    }
  }, [activeId])

  useEffect(() => {
    if (!editor) return
    const doc = documents.find(item => item.id === activeId && canAccess(item, activeEmail))
    if (doc && editor.getHTML() !== doc.content) editor.commands.setContent(doc.content || '<p></p>', { emitUpdate: false })
    editor.setEditable(Boolean(doc))
  }, [activeId, activeEmail, editor])

  async function syncCloud(nextDocs: DocumentRecord[]) {
    if (!supabase) return
    try {
      const { error } = await supabase.from('documents').upsert(nextDocs.map(doc => ({
        id: doc.id, title: doc.title, content: doc.content, owner_email: doc.owner,
        shared_with: doc.sharedWith, created_at: doc.createdAt, updated_at: doc.updatedAt
      })))
      if (error) setToast({ message: `Saved locally; cloud sync failed: ${error.message}`, kind: 'error' })
    } catch { setToast({ message: 'Saved locally; cloud sync is unavailable.', kind: 'error' }) }
  }

  function persist(next: DocumentRecord[]) {
    setDocuments(next)
    saveDocuments(next)
    void syncCloud(next)
  }

  function newDocument() {
    const doc = createDocument(activeEmail)
    persist([doc, ...documents])
    setActiveId(doc.id)
    setFilter('all')
    setToast({ message: 'New document created' })
    setMobileNav(false)
  }

  function updateTitle(title: string) {
    setDocuments(old => old.map(doc => doc.id === activeId ? { ...doc, title: title.slice(0, 120) || 'Untitled document', updatedAt: new Date().toISOString() } : doc))
  }

  function switchUser(email: string) {
    setActiveUser(email)
    setActiveEmail(email)
    const next = documents.find(doc => canAccess(doc, email))
    setActiveId(next?.id ?? '')
    setFilter('all')
    setToast({ message: `Viewing workspace as ${DEMO_USERS.find(u => u.email === email)?.name ?? email}` })
  }

  function shareDocument() {
    if (!activeDoc || activeDoc.owner !== activeEmail) {
      setShareError('Only the document owner can change sharing in this demo.')
      return
    }
    const email = shareEmail.trim().toLowerCase()
    if (!DEMO_USERS.some(user => user.email === email)) {
      setShareError('Choose one of the seeded demo users: aarav@example.com or priya@example.com.')
      return
    }
    if (email === activeEmail) {
      setShareError('You already own this document.')
      return
    }
    const next = documents.map(doc => doc.id === activeId
      ? { ...doc, sharedWith: doc.sharedWith.includes(email) ? doc.sharedWith : [...doc.sharedWith, email], updatedAt: new Date().toISOString() }
      : doc)
    persist(next)
    setShareError('')
    setShareEmail('')
    setShareOpen(false)
    setToast({ message: `Shared with ${email}` })
  }

  function removeShare(email: string) {
    if (!activeDoc || activeDoc.owner !== activeEmail) return
    persist(documents.map(doc => doc.id === activeId ? { ...doc, sharedWith: doc.sharedWith.filter(item => item !== email), updatedAt: new Date().toISOString() } : doc))
    setToast({ message: `Access removed for ${email}` })
  }

  async function handleUpload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return
    if (!/\.(txt|md)$/i.test(file.name)) {
      setToast({ message: 'Please upload a .txt or .md file. DOCX import is not supported.', kind: 'error' })
      return
    }
    if (file.size > 1024 * 1024) {
      setToast({ message: 'File must be smaller than 1 MB.', kind: 'error' })
      return
    }
    try {
      const text = await file.text()
      const imported = importTextFile(file.name, text)
      const doc = { ...createDocument(activeEmail, imported.title), content: imported.content }
      persist([doc, ...documents])
      setActiveId(doc.id)
      setFilter('all')
      setToast({ message: 'File imported as a new document' })
    } catch {
      setToast({ message: 'Could not read this file.', kind: 'error' })
    }
  }

  function downloadMarkdown() {
    if (!activeDoc) return
    const plain = (editor?.getText() ?? '').replace(/\n{3,}/g, '\n\n')
    const blob = new Blob([`# ${activeDoc.title}\n\n${plain}\n`], { type: 'text/markdown;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `${activeDoc.title.replace(/[^a-z0-9-_ ]/gi, '').trim() || 'document'}.md`
    anchor.click()
    URL.revokeObjectURL(url)
    setToast({ message: 'Markdown export downloaded' })
  }

  function deleteDocument() {
    if (!activeDoc || activeDoc.owner !== activeEmail) return
    if (!window.confirm(`Delete "${activeDoc.title}"? This cannot be undone.`)) return
    const next = documents.filter(doc => doc.id !== activeId)
    persist(next)
    setActiveId(next.find(doc => canAccess(doc, activeEmail))?.id ?? '')
    setToast({ message: 'Document deleted' })
    setMoreOpen(false)
  }

  const isOwner = activeDoc?.owner === activeEmail
  const sharedCount = activeDoc?.sharedWith.length ?? 0

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
        <div className="brand-row">
          <div className="brand-mark"><FileText size={21} strokeWidth={2.5} /></div>
          <span className="brand-name">ajaia</span>
          <button className="icon-button mobile-close" aria-label="Close navigation" onClick={() => setMobileNav(false)}><X size={18} /></button>
        </div>
        <button className="create-button" onClick={newDocument}><FilePlus2 size={18} /> New document <span>⌘ N</span></button>
        <div className="search-box"><Search size={16} /><input aria-label="Search documents" placeholder="Search documents" value={search} onChange={e => setSearch(e.target.value)} /></div>
        <div className="nav-label">WORKSPACE</div>
        <nav className="main-nav" aria-label="Document filters">
          <button className={filter === 'all' ? 'nav-item selected' : 'nav-item'} onClick={() => setFilter('all')}><FolderOpen size={17} /> All documents <span>{documents.filter(d => canAccess(d, activeEmail)).length}</span></button>
          <button className={filter === 'owned' ? 'nav-item selected' : 'nav-item'} onClick={() => setFilter('owned')}><FileText size={17} /> My documents</button>
          <button className={filter === 'shared' ? 'nav-item selected' : 'nav-item'} onClick={() => setFilter('shared')}><Users size={17} /> Shared with me</button>
        </nav>
        <div className="sidebar-section-head"><span>RECENT DOCUMENTS</span><button title="Create document" onClick={newDocument}><FilePlus2 size={15} /></button></div>
        <div className="document-list">
          {visibleDocs.map(doc => <button key={doc.id} className={`document-row ${activeDoc?.id === doc.id ? 'doc-active' : ''}`} onClick={() => { setActiveId(doc.id); setMobileNav(false) }}>
            <span className="doc-icon"><FileText size={16} /></span><span className="doc-row-copy"><span className="doc-row-title">{doc.title}</span><span className="doc-row-time">{doc.owner === activeEmail ? 'Owned by you' : 'Shared by teammate'}</span></span>
          </button>)}
          {!visibleDocs.length && <p className="empty-list">No documents found.</p>}
        </div>
        <div className="sidebar-bottom">
          <div className="storage-card"><div className="storage-icon"><Cloud size={17} /></div><div><strong>{hasCloudStorage ? 'Cloud storage configured' : 'Your workspace'}</strong><p>{hasCloudStorage ? 'Supabase connection enabled' : 'Demo data saves in this browser'}</p></div><span className={`status-dot ${hasCloudStorage ? 'green' : ''}`} /></div>
          <label className="user-switch-label" htmlFor="user-switch">DEMO ACCOUNT</label>
          <div className="user-switch-wrap"><div className="avatar">{currentUser.name.split(' ').map(x => x[0]).join('').slice(0, 2)}</div><div className="user-meta"><strong>{currentUser.name}</strong><span>{currentUser.email}</span></div><ChevronDown size={16} /></div>
          <select id="user-switch" className="user-select" value={activeEmail} onChange={e => switchUser(e.target.value)} aria-label="Switch demo account">
            {DEMO_USERS.map(user => <option key={user.email} value={user.email}>{user.name} ({user.email})</option>)}
          </select>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumbs"><button className="icon-button menu-toggle" aria-label="Open navigation" onClick={() => setMobileNav(true)}><Menu size={19} /></button><span>Workspace</span><span className="crumb-slash">/</span><strong>{activeDoc?.title ?? 'No document selected'}</strong></div>
          <div className="top-actions"><div className="save-state"><span className="save-dot" /><span>Saved</span></div><button className="share-button" onClick={() => { setShareOpen(true); setShareError('') }} disabled={!activeDoc}><Share2 size={16} /> Share <span className="share-count">{sharedCount || ''}</span></button><div className="more-wrap"><button className="icon-button" aria-label="More document actions" onClick={() => setMoreOpen(v => !v)}><MoreHorizontal size={20} /></button>{moreOpen && <div className="more-menu"><button onClick={downloadMarkdown}><Download size={15} /> Export Markdown</button>{isOwner && <button className="danger-action" onClick={deleteDocument}><Trash2 size={15} /> Delete document</button>}</div>}</div></div>
        </header>

        {activeDoc ? <div className="editor-scroll">
          <div className="document-header">
            <div className="document-kicker"><span className="kicker-icon"><FileText size={14} /></span> DOCUMENT <span className="kicker-dot">·</span> {isOwner ? 'OWNED BY YOU' : 'SHARED WITH YOU'}</div>
            <input className="document-title" aria-label="Document title" value={activeDoc.title} maxLength={120} onChange={e => updateTitle(e.target.value)} readOnly={!isOwner} />
            <div className="document-meta"><div className="avatar-stack"><span className="mini-avatar">{currentUser.name.split(' ').map(x => x[0]).join('').slice(0, 2)}</span>{activeDoc.sharedWith.slice(0, 2).map(email => <span className="mini-avatar secondary" key={email}>{DEMO_USERS.find(u => u.email === email)?.name.split(' ').map(x => x[0]).join('') ?? email[0].toUpperCase()}</span>)}</div><span>{isOwner ? 'You' : DEMO_USERS.find(u => u.email === activeDoc.owner)?.name ?? activeDoc.owner}</span><span className="meta-divider">·</span><Clock3 size={13} /><span>Edited {relativeTime(activeDoc.updatedAt)}</span><span className="meta-divider">·</span><span className="private-pill">{isOwner ? 'Private' : 'Shared'}</span></div>
          </div>
          <div className="editor-card">
            <div className="toolbar" role="toolbar" aria-label="Text formatting">
              <div className="toolbar-group"><ToolbarButton label="Paragraph" active={!editor?.isActive('heading')} onClick={() => editor?.chain().focus().setParagraph().run()}><AlignLeft size={17} /></ToolbarButton><span className="toolbar-divider" /><ToolbarButton label="Heading 1" active={editor?.isActive('heading', { level: 1 })} onClick={() => editor?.chain().focus().toggleHeading({ level: 1 }).run()}><Heading1 size={18} /></ToolbarButton><ToolbarButton label="Heading 2" active={editor?.isActive('heading', { level: 2 })} onClick={() => editor?.chain().focus().toggleHeading({ level: 2 }).run()}><Heading2 size={18} /></ToolbarButton></div>
              <span className="toolbar-divider tall" />
              <div className="toolbar-group"><ToolbarButton label="Bold" active={editor?.isActive('bold')} onClick={() => editor?.chain().focus().toggleBold().run()}><Bold size={17} /></ToolbarButton><ToolbarButton label="Italic" active={editor?.isActive('italic')} onClick={() => editor?.chain().focus().toggleItalic().run()}><Italic size={17} /></ToolbarButton><ToolbarButton label="Underline" active={editor?.isActive('underline')} onClick={() => editor?.chain().focus().toggleUnderline().run()}><UnderlineIcon size={17} /></ToolbarButton></div>
              <span className="toolbar-divider tall" />
              <div className="toolbar-group"><ToolbarButton label="Bulleted list" active={editor?.isActive('bulletList')} onClick={() => editor?.chain().focus().toggleBulletList().run()}><List size={18} /></ToolbarButton><ToolbarButton label="Numbered list" active={editor?.isActive('orderedList')} onClick={() => editor?.chain().focus().toggleOrderedList().run()}><ListOrdered size={18} /></ToolbarButton></div>
              <div className="toolbar-spacer" /><span className="toolbar-hint">FORMATTING</span>
            </div>
            <div className="paper-wrap"><EditorContent editor={editor} /></div>
            <div className="editor-footer"><span><Sparkles size={14} /> A calm space for your best work.</span><span>{(editor?.getText() ?? '').trim().split(/\s+/).filter(Boolean).length} words</span></div>
          </div>
          <div className="below-editor-note"><span className="note-check"><Check size={14} /></span><span>Your edits are saved automatically in this browser.</span><span className="note-spacer" /><button onClick={downloadMarkdown}><Download size={14} /> Export .md</button></div>
        </div> : <div className="empty-state"><div className="empty-illustration"><FileText size={28} /></div><h2>Your workspace is ready</h2><p>Create a document or switch to another demo account to explore shared documents.</p><button className="create-button" onClick={newDocument}><FilePlus2 size={17} /> Create a document</button></div>}
      </main>

      <input ref={fileInput} type="file" accept=".txt,.md,text/plain,text/markdown" hidden onChange={handleUpload} />
      <button className="floating-upload" onClick={() => fileInput.current?.click()} title="Import a .txt or .md file"><Upload size={16} /><span>Import file</span></button>
      <button className="import-shortcut" onClick={() => fileInput.current?.click()} aria-label="Import file"><Upload size={17} /></button>

      {shareOpen && activeDoc && <div className="modal-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) setShareOpen(false) }}>
        <section className="share-modal" role="dialog" aria-modal="true" aria-labelledby="share-title">
          <div className="modal-head"><div><h2 id="share-title">Share document</h2><p>Invite a teammate to collaborate on this document.</p></div><button className="icon-button" aria-label="Close share dialog" onClick={() => setShareOpen(false)}><X size={19} /></button></div>
          <div className="share-doc-name"><FileText size={17} /><span>{activeDoc.title}</span><span className="access-badge">{isOwner ? 'Owner' : 'Viewer'}</span></div>
          {isOwner ? <><label className="field-label" htmlFor="share-email">Add people</label><div className="invite-row"><input id="share-email" type="email" list="demo-emails" placeholder="teammate@example.com" value={shareEmail} onChange={e => setShareEmail(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') shareDocument() }} /><datalist id="demo-emails">{DEMO_USERS.filter(u => u.email !== activeEmail).map(u => <option key={u.email} value={u.email} />)}</datalist><button className="primary-small" onClick={shareDocument}>Share</button></div>{shareError && <p className="form-error">{shareError}</p>}</> : <p className="permission-note">Only the owner can invite or remove people in this demo.</p>}
          <div className="people-heading">People with access <span>{1 + activeDoc.sharedWith.length}</span></div>
          <div className="person-row"><div className="avatar">{DEMO_USERS.find(u => u.email === activeDoc.owner)?.name.split(' ').map(x => x[0]).join('') ?? 'OW'}</div><div className="person-info"><strong>{activeDoc.owner === activeEmail ? 'You' : DEMO_USERS.find(u => u.email === activeDoc.owner)?.name ?? activeDoc.owner}</strong><span>{activeDoc.owner}</span></div><span className="role-label">Owner</span></div>
          {activeDoc.sharedWith.map(email => <div className="person-row" key={email}><div className="avatar secondary">{DEMO_USERS.find(u => u.email === email)?.name.split(' ').map(x => x[0]).join('') ?? email[0].toUpperCase()}</div><div className="person-info"><strong>{email === activeEmail ? 'You' : DEMO_USERS.find(u => u.email === email)?.name ?? email}</strong><span>{email}</span></div>{isOwner ? <button className="remove-access" onClick={() => removeShare(email)} title={`Remove ${email}`}><X size={15} /></button> : <span className="role-label">Editor</span>}</div>)}
          <div className="modal-foot"><span><Users size={14} /> Demo sharing · seeded accounts only</span><button className="done-button" onClick={() => setShareOpen(false)}>Done</button></div>
        </section>
      </div>}
      {toast && <div className={`toast ${toast.kind === 'error' ? 'toast-error' : ''}`} role="status"><span className="toast-icon">{toast.kind === 'error' ? <X size={15} /> : <Check size={15} />}</span>{toast.message}</div>}
    </div>
  )
}