import type { DocumentRecord } from '../types'
import { STARTER_CONTENT } from '../types'

const KEY = 'ajaia.documents.v1'
const USER_KEY = 'ajaia.active-user.v1'

function now() { return new Date().toISOString() }
function makeId() { return globalThis.crypto?.randomUUID?.() ?? `doc-${Date.now()}-${Math.random().toString(16).slice(2)}` }

export function initialDocuments(owner = 'dhaval@example.com'): DocumentRecord[] {
  const date = now()
  return [
    { id: 'welcome-doc', title: 'Welcome to Ajaia', content: STARTER_CONTENT, owner, sharedWith: ['aarav@example.com'], createdAt: date, updatedAt: date },
    { id: 'project-plan', title: 'Product launch plan', content: '<h1>Product launch plan</h1><p><strong>Goal:</strong> Ship a focused, reliable first version.</p><h2>Milestones</h2><ol><li>Confirm the core workflow</li><li>Implement and test the editor</li><li>Gather feedback and iterate</li></ol>', owner, sharedWith: [], createdAt: date, updatedAt: date },
    { id: 'meeting-notes', title: 'Team meeting notes', content: '<h1>Team meeting notes</h1><p><em>Date:</em> Add meeting date here</p><h2>Discussion</h2><ul><li>Wins this week</li><li>Open questions</li><li>Next actions</li></ul>', owner: 'aarav@example.com', sharedWith: [owner], createdAt: date, updatedAt: date }
  ]
}

export function loadDocuments(): DocumentRecord[] {
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as DocumentRecord[]
      if (Array.isArray(parsed)) return parsed
    }
  } catch { /* Recover with seed data if local storage is unavailable or malformed. */ }
  const seeded = initialDocuments()
  saveDocuments(seeded)
  return seeded
}

export function saveDocuments(documents: DocumentRecord[]) {
  localStorage.setItem(KEY, JSON.stringify(documents))
}

export function getActiveUser() {
  return localStorage.getItem(USER_KEY) || 'dhaval@example.com'
}

export function setActiveUser(email: string) {
  localStorage.setItem(USER_KEY, email)
}

export function createDocument(owner: string, title = 'Untitled document'): DocumentRecord {
  const date = now()
  return { id: makeId(), title: title.trim() || 'Untitled document', content: '<p></p>', owner, sharedWith: [], createdAt: date, updatedAt: date }
}

export function canAccess(doc: DocumentRecord, email: string) {
  return doc.owner === email || doc.sharedWith.includes(email)
}

export function canEdit(doc: DocumentRecord, email: string) {
  return canAccess(doc, email)
}

export function importTextFile(fileName: string, text: string): Pick<DocumentRecord, 'title' | 'content'> {
  const title = fileName.replace(/\.(txt|md)$/i, '').trim() || 'Imported document'
  const escaped = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  const content = escaped.split(/\r?\n/).map(line => line.trim() ? `<p>${line}</p>` : '<p></p>').join('')
  return { title, content: content || '<p></p>' }
}