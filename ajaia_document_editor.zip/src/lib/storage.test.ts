import { describe, expect, it } from 'vitest'
import { canAccess, canEdit, importTextFile } from './storage'
import type { DocumentRecord } from '../types'

const doc: DocumentRecord = {
  id: '1', title: 'Plan', content: '<p>hello</p>', owner: 'owner@example.com',
  sharedWith: ['teammate@example.com'], createdAt: '2026-01-01', updatedAt: '2026-01-01'
}

describe('document access and import', () => {
  it('allows the owner and invited teammate, but not an unrelated user', () => {
    expect(canAccess(doc, 'owner@example.com')).toBe(true)
    expect(canEdit(doc, 'teammate@example.com')).toBe(true)
    expect(canAccess(doc, 'stranger@example.com')).toBe(false)
  })

  it('imports plain text safely and derives a readable title', () => {
    const imported = importTextFile('notes.txt', '<script>alert(1)</script>\nsecond line')
    expect(imported.title).toBe('notes')
    expect(imported.content).toContain('&lt;script&gt;')
    expect(imported.content).toContain('<p>second line</p>')
  })
})