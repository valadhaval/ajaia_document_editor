export type DocumentRecord = {
  id: string
  title: string
  content: string
  owner: string
  sharedWith: string[]
  updatedAt: string
  createdAt: string
}

export type User = { name: string; email: string }

export const DEMO_USERS: User[] = [
  { name: 'Dhaval Vala', email: 'dhaval@example.com' },
  { name: 'Aarav Shah', email: 'aarav@example.com' },
  { name: 'Priya Patel', email: 'priya@example.com' }
]

export const STARTER_CONTENT = `<h1>Welcome to Ajaia</h1><p>Your team's ideas deserve a clear place to grow.</p><p>Use this document to capture thoughts, plan work, and share updates with your team.</p><h2>Getting started</h2><ul><li>Format text using the toolbar above.</li><li>Rename this document from the title field.</li><li>Share it with a teammate using the Share button.</li></ul><p><strong>Tip:</strong> Your changes save automatically in this demo workspace.</p>`
